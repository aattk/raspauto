def login(id,password):
    print(id+password)